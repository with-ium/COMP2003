public class Pressurising extends State {

    public Pressurising(Airlock airlock) {
        super(airlock);
    }

    // waiting state

    @Override
    public void depressurise() {
        airlock.getPump().stop();
        airlock.getPump().beginExtraction();
        airlock.setState(new Depressurising(airlock));
    }

    @Override
    public void pressurise() {}

    @Override
    public void openInnerDoor() {}

    @Override
    public void openOuterDoor() {}

    @Override
    public void updatePressure(double pressure) {
        if (pressure < 5) {
            airlock.setState(new Depressurised(airlock));
        }
    }

     
}
