public abstract class State {
    Airlock airlock;

    State(Airlock airlock) {
        this.airlock = airlock;
    }

    public abstract void pressurise();
    public abstract void depressurise();
    public abstract void updatePressure(double pressure);
    public abstract void openInnerDoor();
    public abstract void openOuterDoor();
}
