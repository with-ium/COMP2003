public class Sensor {
    public double getPressure() {}
}
