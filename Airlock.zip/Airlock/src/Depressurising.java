public class Depressurising extends State {

    public Depressurising(Airlock airlock) {
        super(airlock);
    }

    // waiting state;

    @Override
    public void depressurise() {}

    @Override
    public void pressurise() {
        airlock.getPump().stop();
        airlock.getPump().beginReturn();
        airlock.setState(new Pressurising(airlock));
    }

    @Override
    public void openInnerDoor() {}

    @Override
    public void openOuterDoor() {}

    @Override
    public void updatePressure(double pressure) {
        if (pressure > 90) {
            airlock.setState(new Depressurised(airlock));
        }
    }
}