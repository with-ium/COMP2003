public class Airlock_ {
    private static final int PRESSURISED = 0;
    private static final int DEPRESSURISED = 1;
    private static final int PRESSURISING = 2;
    private static final int DEPRESSURISING = 3;

    private Sensor sensor;
    private Pump pump;
    private Door[] doors;

    private int state = PRESSURISED;

    public Airlock_(Sensor pSensor, Pump pPump, Door[] pDoors) {
        sensor = pSensor;
        pump = pPump;
        doors = pDoors;
    }

    public Sensor getSensor() { return sensor; }
    public Pump getPump() { return pump; }
    public Door[] getDoor() { return doors; }

    public void setSensor(Sensor pSensor) { /* ... */ }
    public void setPump(Pump pPump) { /* ... */ }
    public void setDoor(Door[] pDoors) { /* ... */ }

    public void pressurise() {
        switch(state) {
            case PRESSURISED:
                break;
            case DEPRESSURISED:
                this.getPump().beginReturn();
                state = PRESSURISING;
                break;
            case PRESSURISING:
                break;
            case DEPRESSURISING:
                this.getPump().stop();
                this.getPump().beginReturn();
                state = PRESSURISING;
                break;
        }
    }

    public void depressurise() {
        switch(state) {
            case PRESSURISED:
                this.getPump().beginExtraction();
                state = DEPRESSURISING;
                break;
            case DEPRESSURISED:
                break;
            case PRESSURISING:
                this.getPump().stop();
                this.getPump().beginExtraction();
                state = DEPRESSURISING;
                break;
            case DEPRESSURISING:
                break;
        }
    }

    public void openInnerDoor() {
        if (this.getDoor()[1].isOpen() == false) {
            Door innerDoor = this.getDoor()[0];
            innerDoor.open();
        }
    }

    public void openOuterDoor() {
        if (this.getDoor()[0].isOpen() == false) {
            Door outerDoor = this.getDoor()[1];
            outerDoor.open();
        } 
    }

    public void updatePressure(double pressure) {
        switch(state) {
            case DEPRESSURISING:
                if (pressure < 5) {
                    state = DEPRESSURISED;
                }
                break;
            case PRESSURISING:
                if (pressure > 90) {
                    state = PRESSURISED;
                }
                break;
        }
    }
}

