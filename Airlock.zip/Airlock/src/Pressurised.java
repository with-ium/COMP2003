public class Pressurised extends State {

    public Pressurised(Airlock airlock) {
        super(airlock);
    }

    @Override
    public void depressurise() {
        airlock.getPump().beginExtraction();
        airlock.setState(new Depressurising(airlock));
    }

    @Override
    public void pressurise() {}

    @Override
    public void openInnerDoor() {
        if (airlock.getDoor()[1].isOpen() == false) {
            Door innerDoor = airlock.getDoor()[0];
            innerDoor.open();
        } 
    }

    @Override
    public void openOuterDoor() {}

    @Override
    public void updatePressure(double pressure) {}

}
