public class Door {
    public boolean isOpen() {}
    public void open() {}
}
