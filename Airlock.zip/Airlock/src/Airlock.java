public class Airlock {
    private Sensor sensor;
    private Pump pump;
    private Door[] doors;

    private State state = new Pressurised(this);

    public Airlock(Sensor pSensor, Pump pPump, Door[] pDoors) {
        sensor = pSensor;
        pump = pPump;
        doors = pDoors;
    }

    public Sensor getSensor() { return sensor; }
    public Pump getPump() { return pump; }
    public Door[] getDoor() { return doors; }

    public void setSensor(Sensor pSensor) { /* ... */ }
    public void setPump(Pump pPump) { /* ... */ }
    public void setDoor(Door[] pDoors) { /* ... */ }

    public void setState(State pState) {
        this.state = pState;
    }

    public void pressurise() {
        state.pressurise();
    }

    public void depressurise() {
        state.depressurise();
    }

    public void openInnerDoor() {
        state.openInnerDoor();
    }

    public void openOuterDoor() {
        state.openOuterDoor();
    }

    public void updatePressure(double pressure) {
        state.updatePressure(pressure);
    }
}

