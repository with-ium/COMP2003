public class Pump {
    public void beginExtraction() {}
    public void beginReturn() {}
    public void stop() {}
}
