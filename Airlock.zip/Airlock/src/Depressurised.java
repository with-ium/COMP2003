public class Depressurised extends State {

    public Depressurised(Airlock airlock) {
        super(airlock);
    }

    @Override
    public void depressurise() {}

    @Override
    public void pressurise() {
        airlock.getPump().beginReturn();
        airlock.setState(new Pressurising(airlock));
    }

    @Override
    public void openInnerDoor() {}

    @Override
    public void openOuterDoor() {
        if (airlock.getDoor()[0].isOpen() == false) {
            Door outerDoor = airlock.getDoor()[1];
            outerDoor.open();
        } 
    }

    @Override
    public void updatePressure(double pressure) {}
}
