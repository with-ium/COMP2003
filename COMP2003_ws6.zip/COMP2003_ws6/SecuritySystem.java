public class SecuritySystem implements SensorObserver
{
    private MotionSensor motionSensor;
    private HeatSensor heatSensor
    private Alarm alarm;
    private boolean armed;
    private EmailSystem emailSystem;

    public SecuritySystem(EmailSystem pEmailSystem, MotionSensor pMotionSensor, HeatSensor pHeatSensor, Alarm pAlarm, boolean pArmed)
    {
        motionSensor = pMotionSensor;
        heatSensor = pHeatSensor;
        motionSensor.addSensorObserver(this);
        heatSensor.addSensorObserver(this);
        alarm = pAlarm;
        armed = pArmed;
        emailSystem = pEmailSystem;
    }

    public void setArmed(boolean newArmed)
    {
        armed = newArmed;
        emailSystem.sendMessage("Armed: " + newArmed);
    }

    @Override
    public void sensorDetection(Sensor s)
    {
        if(armed)
        {
            alarm.ring();
            emailSystem.sendMessage("Sensor detection for " + s.toString());
        }
    }
}

/** Injector code below: */ 
/*
    main() {
        public Hardware hw = new Hardware();
        public SensorBundle sens = hw.getSensors();
        public MotionSensor motionSensor = sens.getMotionSensor();
        public HeatSensor heatSensor = sens.getHeatSensor();
        public Alarm alarm = new Alarm();
        public boolean armed = false;
        public EmailSystem emailSystem = new EmailSystem();
        
        public SecuritySystem ss = new SecuritySystem(emailSystem, motionSensor, heatSensor, alarm, armed);
    }
*/ 