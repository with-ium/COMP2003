package edu.curtin.spaceprobe;

import java.util.*;

public class SensorManager<E, T extends Set<E>> implements Resource<T>
{
    private Set<Sensor> workingSensors;
    private int nSensors;

    public SensorManager(Set<Sensor> sensors)
    {
        workingSensors = new HashSet<>();
        workingSensors.addAll(sensors);
        nSensors = sensors.size();
    }

    @Override
    public void useUp(T amount)
    {
        for(Sensor sensor : amount)
        {
            workingSensors.remove(sensor);
        }
    }

    @Override
    public T getRemaining()
    {
        return Collections.unmodifiableSet(workingSensors);
    }

    @Override
    public <U extends Number> long getTime(U elapsedTime)
    {
        double nWorking = Double.valueof(workingSensors.size());
        return (Double.valueOf(elapsedTime) / (Double.valueOf(nSensors) - nWorking) * nWorking).longValue();
    }
}
