package edu.curtin.spaceprobe;

public class Battery<T extends Number> implements Resource
{
    private double charge = 100.0;

    public void recharge()
    {
        charge = 100.0;
    }

    @Override
    public <U extends Number> void useUp(U amount)
    {
        charge -= amount.doubleValue();
    }

    @Override
    public T getRemaining()
    {
        return charge;
    }

    @Override
    public <U extends Number> long getTime(U elapsedTime)
    {
        return (Double.valueOf(elapsedTime) / (100.0 - charge) * charge).longValue();
    }
}
