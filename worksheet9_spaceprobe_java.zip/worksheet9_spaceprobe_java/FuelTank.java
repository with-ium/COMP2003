package edu.curtin.spaceprobe;

public class FuelTank<T> implements Resource<T>
{
    private double oxygen = 100.0;
    private double hydrogen = 100.0;

    @Override
    public void useUp(T amount)
    {
        FuelAmount fuelUsage = amount;
        this.oxygen -= fuelUsage.getOxygen();
        this.hydrogen -= fuelUsage.getHydrogen();
    }

    @Override
    public T getRemaining()
    {
        return new FuelAmount(hydrogen, oxygen);
    }

    @Override
    public <U extends Number> long getTime(U elapsedTime)
    {
        return Math.min(
            Double.valueOf(elapsedTime) / (100.0 - oxygen) * oxygen,
            Double.valueOf(elapsedTime) / (100.0 - hydrogen) * hydrogen).longValue();
    }
}
