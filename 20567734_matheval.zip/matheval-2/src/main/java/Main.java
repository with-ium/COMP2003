package edu.curtin.matheval;

import java.text.ParseException;
import java.util.Scanner;

/**
 * Entry point for out mathematical expression app.
 */
public class Main
{
    public static void main(String[] args) throws ParserException
    {
        System.out.print("Enter a mathematical expression: ");
        ExprNode exprRoot = null;
        String expression;
        try(Scanner sc = new Scanner(System.in))
        {
            expression = sc.nextLine();
            exprRoot = new ExprParser().parse(expression);
            System.out.printf("Parsed expression: '%s'\nEvaluating for different values of x...\n", exprRoot.toString());
            for(double x = 0.0; x <= 10.00001; x += 0.5)
            {
                System.out.printf("(%.2f, %.2f)\n", x, exprRoot.evaluate(x));
            }
        }
        catch (ParserException e) {
            System.out.println(e);
            throw new ParserException();
        }
            
        
    }
}
