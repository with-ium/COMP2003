package edu.curtin.matheval;

import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.ParserConfigurationException;

import edu.curtin.matheval.ParserException;

import java.util.logging.*;

/**
 * Parses mathematical expressions, and builds a tree of ExprNode objects to represent the parsed 
 * expression.
 */
public class ExprParser
{
    // The regex pattern used for tokenisation purposes. Basically, this skips any amount of 
    // whitespace, then checks for a fractional number (containing and possibly starting with "."),
    // then checks for an integer, and finally falls back to a single other character of any type.
    private static final Pattern TOKEN = Pattern.compile("\\s*([0-9]*\\.[0-9]+|[0-9]+|.)");

    private static final Logger logger = Logger.getLogger(ExprParser.class.getName());
    
    public ExprParser() {}

    /**
     * Parses a string, which is assumed to contain a mathematical expression. Returns the root 
     * node of the resulting object tree.
     */
    public ExprNode parse(String s) throws ParserException
    {
        logger.info("Parsing string!");
        List<String> tokens = new LinkedList<>();

        // Tokenise the string, by repeatedly applying the 'TOKEN' regular expression until it 
        // doesn't match anymore (which should only happen at the end of the string).
        String substr = s;
        boolean done = false;
        do
        {
            Matcher matcher = TOKEN.matcher(substr);
            if(matcher.lookingAt())
            {
                tokens.add(matcher.group(1));
                
                substr = substr.substring(matcher.end());
            }
            else
            {
                done = true;
            }
        }
        while(!done);

        // Invoke the actual parsing logic.
        if (tokens.size() == 0) {
            throw new ParserException("Empty mathematical expression!");
        }
        return parseAdd(tokens);
    }

    /** 
     * Parses a sequence of zero-or-more "+" / "-" operators (the lowest operator precedence
     * level).
     */
    private ExprNode parseAdd(List<String> tokens) throws ParserException
    {
        logger.info("Parsing + / - operator sequence!");
        ExprNode node = parseMul(tokens);
        boolean end = false;
        while(!end && !tokens.isEmpty())
        {
            // Expect next token to be '+' or '-'
            String token = tokens.remove(0);
            switch(token)
            {
                case "+": 
                    logger.fine(tokens.toString());
                    try {
                        node = new AddOperator(node, parseMul(tokens));
                    }
                    catch (IndexOutOfBoundsException e) {
                        throw new ParserException("Invalid expression with '+'");
                    }
                    break;
                    
                case "-":
                    logger.fine(tokens.toString());
                    try {
                        node = new SubOperator(node, parseMul(tokens));
                    }
                    catch (IndexOutOfBoundsException e) {
                        throw new ParserException("Invalid expression with '-'");
                    }
                    break;
                    
                default:
                    // The next token isn't "+" or "-", which means we assume this additive 
                    // sequence is over, so push the token back onto the list, and end.
                    logger.fine(tokens.toString());
                    tokens.add(0, token);
                    
                    end = true;
                    break;
            }
        }
        return node;
    }
    
    /**
     * Parses a sequence of zero-or-more "*" / "/" operators.
     */
    private ExprNode parseMul(List<String> tokens) throws ParserException
    {
        logger.info("Parsing * / div operator sequence!");
        ExprNode node = parsePrimary(tokens);
        boolean end = false;
        while(!end && !tokens.isEmpty())
        {
            // Expect next token to be "*" or "/"
            String token = tokens.remove(0);
            switch(token)
            {
                case "*":
                    logger.fine(tokens.toString());
                    try {
                        node = new MulOperator(node, parsePrimary(tokens));
                    }
                    catch (IndexOutOfBoundsException e) {
                        throw new ParserException("Invalid expression with '*'");
                    }
                    break;
                    
                case "/":
                    logger.fine(tokens.toString());
                    try {
                        node = new DivOperator(node, parsePrimary(tokens));
                    }
                    catch (IndexOutOfBoundsException e) {
                        throw new ParserException("Invalid expression with '/'");
                    }
                    break;
                    
                default:
                    logger.fine(tokens.toString());
                    // The next token isn't "*" or "/", which means we assume this multiplicative
                    // sequence is over, so push the token back onto the list, and end.
                    tokens.add(0, token);
                    end = true;
                    break;
            }
        }
        return node;
    }
    
    /**
     * Parses a "primary" value, which can be either a sub-expression in brackets, a negation "-"
     * operator, a reference to the "x" variable, or a literal number.
     */
    private ExprNode parsePrimary(List<String> tokens) throws ParserException
    {
        logger.info("Parsing primary value sequence!");
        ExprNode node;
        String token = tokens.remove(0); // Obtain the next token
        switch(token)
        {
            case "(":
                // Sub-expression inside brackets.
                logger.fine(tokens.toString());
                try {
                    node = parseAdd(tokens);
                }
                catch (IndexOutOfBoundsException e) {
                    throw new ParserException("Unexpected token '('");
                }
                tokens.remove(0); // Remove closing ")"
                break;
                
            case "-":
                // Inverted value (e.g., -(x+1))
                logger.fine(tokens.toString());
                try {
                    node = new NegationOperator(parsePrimary(tokens));
                }
                catch (IndexOutOfBoundsException e) {
                    throw new ParserException("Unexpected token '-'");
                }
                break;
                
            case "x":
                // Variable value
                logger.fine(tokens.toString());
                node = new XValue();
                break;
                
            default:
                // Literal number or another variable
                logger.fine(tokens.toString());
                try {
                    node = new Value(Double.parseDouble(token));
                }
                catch (NumberFormatException e) {
                    throw new ParserException("Unexpected token '" + token + "'");
                }
                
                break;
        }
        return node;
    }
}
